//
//  HomeViewController.swift
//  AttendanceSystem
//
//  Created by Student on 02/09/2022.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var registerBtn: UIButton!
    
    var userType: UserRole = .Student

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Faculty"
        if userType == .Student {
            
            self.navigationItem.title = "Student"
        }
        
        self.navigationController?.navigationBar.isHidden = false
        loginBtn.RoundCorners(radius: 8)
        registerBtn.RoundCorners(radius: 8)
    }
    
    
    @IBAction func loginBtnClicked(_ sender: Any) {
        
        let VC = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        VC.userType = userType
        self.navigationController!.pushViewController(VC, animated: true)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
    
    @IBAction func registerBtnClicked(_ sender: Any) {
        
        if userType == .Student {
            
            let VC = self.storyboard?.instantiateViewController(withIdentifier: "StudentRegisterVC") as! StudentRegisterVC
            self.navigationController!.pushViewController(VC, animated: true)
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        }else{
            
            let VC = self.storyboard?.instantiateViewController(withIdentifier: "FacultyRegisterVC") as! FacultyRegisterVC
            self.navigationController!.pushViewController(VC, animated: true)
            self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        }
    }
}
