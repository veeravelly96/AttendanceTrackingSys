//
//  StudentCheckAttendaceVC.swift
//  AttendanceSystem
//
//  Created by Student on 06/09/2022.
//

import UIKit

class StudentCheckAttendaceVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Student"
    }
}
